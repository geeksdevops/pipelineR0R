package com.fcaa.devops.approval

/**************************************************
***** Function to send the email for approval *****
***************************************************/
def sendApprovalEmail()
{
    try {
      wrap([$class: 'AnsiColorBuildWrapper']) {
        println "\u001B[32mINFO => sending email for approval to send the pull request..."
		String BODY="""
<HTML>
<BODY BGCOLOR='#eafaf1'>
<PRE>
Hi,

This is regarding jenkins job $JOB_NAME of build number ${BUILD_NUMBER} is waiting for your immediate action.

To raise the pull request to upper branch go to ${BUILD_URL}input.

It will wait for your approval for maximum 10 minutes. Build will abort in absence of your response in specified time frame.

In case of any doubt please drop email at FCAADevOps@sapient.com.

Thanks,
DevOps Team
</PRE>
</BODY>
</HTML>"""
        mail bcc: '', body: "${BODY}", cc: '', from: 'DevOps@fcaab.com.au', mimeType: 'text/html', replyTo: 'FCAADevOps@sapient.com', subject: "Jenkins job ${env.JOB_NAME} is waiting for your input", to: "jkumar19@sapient.com,hbansal2@sapient.com"
	  }
    }
    catch (Exception caughtException){
	  wrap([$class: 'AnsiColorBuildWrapper']) {
        println "\u001B[41mERROR => failed to send the email for approval, exiting..."
        currentBuild.result = 'FAILED'
        throw caughtException
      }
    }
}

/******************************************
***** Function to wait for user input *****
*******************************************/
def waitForUserInput()
{
    def userInput=true
    def didTimeout=false
    try {
       wrap([$class: 'AnsiColorBuildWrapper']) {
          println "\u001B[32mINFO => sending email for approval to send the pull request..."
          timeout(time: 10, unit: 'MINUTES') 
          { 
             userInput = input(id: 'Proceed1', message: 'Are we good to raise pull request?', parameters: [[$class: 'BooleanParameterDefinition', defaultValue: true, description: '', name: 'Please confirm if you are OK']])
          }        
       }
    }
    catch (Exception caughtException) {
       def user = err.getCauses()[0].getUser()
       if('SYSTEM' == user.toString()) 
       {
          didTimeout = true
       } 
       else 
       {
          userInput = false
          echo "Aborted by: [${user}]"
       }
    }
    if (didTimeout) 
    {
       wrap([$class: 'AnsiColorBuildWrapper']) {
         println "\u001B[32mINFO => No input was received before timeout"
       }
    } 
    else if (userInput == true) 
    {
        wrap([$class: 'AnsiColorBuildWrapper']) {
          println "\u001B[32mINFO => INFO => raising pull request, please wait..."
          return 'raisePullRequestPlease'
        }
    } 
    else 
    {
        wrap([$class: 'AnsiColorBuildWrapper']) {
          println "\u001B[32mINFO => can't proceed with the pull request, user aborted it"
        }
    } 
}
