/*************************************************************************
**** Description :: This groovy code is used to run the fcaa pipeline ****
**** Created By  :: DevOps Team                                       ****
**** Created On  :: 12/14/2017                                        ****
**** version     :: 1.0                                               ****
**************************************************************************/
import com.fcaa.devops.scm.*
import com.fcaa.devops.build.npm.*
import com.fcaa.devops.sonar.npm.*
import com.fcaa.devops.deploy.*
import com.fcaa.devops.notification.*

def call(body) 
{
   def config = [:]
   body.resolveStrategy = Closure.DELEGATE_FIRST
   body.delegate = config
   body()
   timestamps {
     try {
        currentBuild.result = "SUCCESS"
        NEXT_STAGE = "none"
        branch_name = new ChoiceParameterDefinition('BRANCH_NAME', ['development','staging'] as String[], 'select branch to build the code')
        value = input(message: 'Please select specified inputs', parameters: [branch_name])		
        if(value == 'development') {
          ENVIRONMENT = 'development'
          BRANCH = 'development'
          BUCKET_NAME = 'app-dev.fcaab.com.au'
        }
	 if(value == 'staging') {
          ENVIRONMENT = 'staging'
          BRANCH = 'staging'
          BUCKET_NAME = 'app-test.fcaab.com.au'
        }
        stage ('\u2776 Code Checkout') {
          def g = new git()
          g.Checkout("${config.GIT_URL}","${BRANCH}","${config.GIT_CREDENTIALS}")
          NEXT_STAGE='code_scanning'
        }
        stage ('\u2777 Pre-Build Tasks') {
           parallel (
             "\u2460 Code Scanning" : {
                while(NEXT_STAGE != 'code_scanning') {
                  continue
                }    
                def g = new nodeJS()
	            g.esLint("${config.ESLINT_CONFIG_FILE}","${config.CHECKSTYLE_FILE}")
                NEXT_STAGE='checkstyle'
             },
             "\u2461 Checkstyle Publish" : {
                while(NEXT_STAGE != 'checkstyle') {
                  continue
                }
	            g = new checkstyle()
	            g.checkstyleReport("${config.CHECKSTYLE_FILE}")
             },
             failFast: true
           )
	    }
       stage ('\u2778 Build Tasks') {
           parallel (
             "\u2460 Node Build" : {
                def g = new nodeJS()
                g.npmBuild()
                NEXT_STAGE='code_analysis'
             },
             "\u2461 Code Analysis" : {
                while(NEXT_STAGE != 'code_analysis') {
                  continue
                }
                def g = new nodeJSAnalysis()
	            g.nodeJSSonarAnalysis("${config.SONAR_PROPERTY}")
             },
             failFast: true
           )
	    }
        stage ('\u2779 Post-Build Tasks') {
           parallel (
             "\u2460 Node Deploy" : {
	            def g = new s3()
	            g.s3Deploy("${BUCKET_NAME}")
                NEXT_STAGE='send_alert'
             },
             "\u2461 Deployment Alert" : {
                while(NEXT_STAGE != 'send_alert') {
                  continue
                }
                def e = new email()
                e.sendDeployEmail("${config.BRAND_NAME}","${ENVIRONMENT}")
             },
             failFast: true
           )
        }
     }
     catch (Exception caughtError) {
        wrap([$class: 'AnsiColorBuildWrapper']) {
            print "\u001B[41mERROR => fcaa pipeline failed, check detailed logs..."
            currentBuild.result = "FAILURE"
            throw caughtError
        }
     }
     finally {
         def e = new email()
         String BODY = new File("${WORKSPACE}/${config.EMAIL_TEMPLATE}").text   
         e.sendemail("${currentBuild.result}","$BODY","${config.RECIPIENT}","${ENVIRONMENT}")
     }
   }
}
